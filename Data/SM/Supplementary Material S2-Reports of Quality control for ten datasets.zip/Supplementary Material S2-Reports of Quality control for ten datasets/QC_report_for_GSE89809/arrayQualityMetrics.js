// (C) Wolfgang Huber 2010-2011

// Script parameters - these are set up by R in the function 'writeReport' when copying the 
//   template for this script from arrayQualityMetrics/inst/scripts into the report.

var highlightInitial = [ false, true, false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, true, true, false, false, false, false, true, false, false, false, false, false, false ];
var arrayMetadata    = [ [ "1", "GSM2389839_Sample_16.CEL.gz", "1", "2012-12-05T20:54:05Z" ], [ "2", "GSM2389840_Sample_17.CEL.gz", "2", "2012-12-05T22:23:06Z" ], [ "3", "GSM2389841_Sample_18.CEL.gz", "3", "2012-12-05T23:50:09Z" ], [ "4", "GSM2389842_Sample_19.CEL.gz", "4", "2012-12-05T22:15:44Z" ], [ "5", "GSM2389843_Sample_20.CEL.gz", "5", "2012-12-05T23:42:57Z" ], [ "6", "GSM2389844_Sample_21.CEL.gz", "6", "2012-12-05T21:03:20Z" ], [ "7", "GSM2389845_Sample_22.CEL.gz", "7", "2012-12-05T19:44:22Z" ], [ "8", "GSM2389846_Sample_23.CEL.gz", "8", "2012-12-05T22:08:31Z" ], [ "9", "GSM2389847_Sample_24.CEL.gz", "9", "2012-12-05T23:35:45Z" ], [ "10", "GSM2389848_Sample_25.CEL.gz", "10", "2012-12-06T01:02:44Z" ], [ "11", "GSM2389849_Sample_26.CEL.gz", "11", "2012-12-05T20:39:13Z" ], [ "12", "GSM2389850_Sample_27.CEL.gz", "12", "2012-12-05T23:32:08Z" ], [ "13", "GSM2389851_Sample_28.CEL.gz", "13", "2012-12-05T21:14:13Z" ], [ "14", "GSM2389852_Sample_29.CEL.gz", "14", "2012-12-06T00:55:31Z" ], [ "15", "GSM2389853_Sample_30.CEL.gz", "15", "2012-12-05T20:31:59Z" ], [ "16", "GSM2389854_Sample_31.CEL.gz", "16", "2012-12-05T21:57:43Z" ], [ "17", "GSM2389855_Sample_32.CEL.gz", "17", "2012-12-05T23:24:54Z" ], [ "18", "GSM2389856_Sample_33.CEL.gz", "18", "2012-12-06T00:51:55Z" ], [ "19", "GSM2389881_Sample_58.CEL.gz", "19", "2012-12-05T19:37:08Z" ], [ "20", "GSM2389882_Sample_59.CEL.gz", "20", "2012-12-05T20:50:20Z" ], [ "21", "GSM2389883_Sample_60.CEL.gz", "21", "2012-12-05T21:00:31Z" ], [ "22", "GSM2389884_Sample_61.CEL.gz", "22", "2012-12-05T22:26:43Z" ], [ "23", "GSM2389885_Sample_62.CEL.gz", "23", "2012-12-05T19:40:44Z" ], [ "24", "GSM2389886_Sample_63.CEL.gz", "24", "2012-12-06T01:06:23Z" ], [ "25", "GSM2389887_Sample_64.CEL.gz", "25", "2012-12-05T20:42:49Z" ], [ "26", "GSM2389888_Sample_65.CEL.gz", "26", "2012-12-06T00:01:03Z" ], [ "27", "GSM2389889_Sample_66.CEL.gz", "27", "2012-12-05T22:04:56Z" ], [ "28", "GSM2389890_Sample_67.CEL.gz", "28", "2012-12-05T22:37:33Z" ], [ "29", "GSM2389891_Sample_68.CEL.gz", "29", "2012-12-05T19:50:01Z" ], [ "30", "GSM2389892_Sample_69.CEL.gz", "30", "2012-12-05T20:35:35Z" ], [ "31", "GSM2389893_Sample_70.CEL.gz", "31", "2012-12-05T22:01:20Z" ], [ "32", "GSM2389894_Sample_71.CEL.gz", "32", "2012-12-06T00:08:18Z" ], [ "33", "GSM2389919_Sample_96.CEL.gz", "33", "2012-12-05T19:32:55Z" ], [ "34", "GSM2389920_Sample_97.CEL.gz", "34", "2012-12-05T20:57:42Z" ], [ "35", "GSM2389921_Sample_98.CEL.gz", "35", "2012-12-06T01:13:40Z" ], [ "36", "GSM2389922_Sample_99.CEL.gz", "36", "2012-12-06T01:10:03Z" ], [ "37", "GSM2389923_Sample_100.CEL.gz", "37", "2012-12-05T22:12:08Z" ], [ "38", "GSM2389924_Sample_101.CEL.gz", "38", "2012-12-05T23:39:21Z" ], [ "39", "GSM2389925_Sample_102.CEL.gz", "39", "2012-12-05T23:57:25Z" ], [ "40", "GSM2389926_Sample_103.CEL.gz", "40", "2012-12-05T22:33:56Z" ], [ "41", "GSM2389927_Sample_104.CEL.gz", "41", "2012-12-05T19:47:11Z" ], [ "42", "GSM2389928_Sample_105.CEL.gz", "42", "2012-12-06T00:04:39Z" ], [ "43", "GSM2389929_Sample_106.CEL.gz", "43", "2012-12-06T00:59:08Z" ], [ "44", "GSM2389930_Sample_107.CEL.gz", "44", "2012-12-05T21:17:50Z" ], [ "45", "GSM2389931_Sample_108.CEL.gz", "45", "2012-12-05T22:44:48Z" ], [ "46", "GSM2389949_Sample_126.CEL.gz", "46", "2012-12-05T22:19:30Z" ], [ "47", "GSM2389950_Sample_127.CEL.gz", "47", "2012-12-05T23:46:34Z" ], [ "48", "GSM2389951_Sample_128.CEL.gz", "48", "2012-12-05T23:53:48Z" ], [ "49", "GSM2389952_Sample_129.CEL.gz", "49", "2012-12-05T20:46:35Z" ], [ "50", "GSM2389953_Sample_130.CEL.gz", "50", "2012-12-05T22:30:19Z" ], [ "51", "GSM2389954_Sample_131.CEL.gz", "51", "2012-12-05T21:06:57Z" ], [ "52", "GSM2389955_Sample_132.CEL.gz", "52", "2012-12-05T21:10:36Z" ], [ "53", "GSM2389956_Sample_133.CEL.gz", "53", "2012-12-05T22:41:11Z" ], [ "54", "GSM2389957_Sample_134.CEL.gz", "54", "2012-12-05T23:28:29Z" ], [ "55", "GSM2389958_Sample_135.CEL.gz", "55", "2012-12-05T19:52:50Z" ], [ "56", "GSM2389959_Sample_136.CEL.gz", "56", "2012-12-06T00:11:55Z" ] ];
var svgObjectNames   = [ "pca", "dens" ];

var cssText = ["stroke-width:1; stroke-opacity:0.4",
               "stroke-width:3; stroke-opacity:1" ];

// Global variables - these are set up below by 'reportinit'
var tables;             // array of all the associated ('tooltips') tables on the page
var checkboxes;         // the checkboxes
var ssrules;


function reportinit() 
{
 
    var a, i, status;

    /*--------find checkboxes and set them to start values------*/
    checkboxes = document.getElementsByName("ReportObjectCheckBoxes");
    if(checkboxes.length != highlightInitial.length)
	throw new Error("checkboxes.length=" + checkboxes.length + "  !=  "
                        + " highlightInitial.length="+ highlightInitial.length);
    
    /*--------find associated tables and cache their locations------*/
    tables = new Array(svgObjectNames.length);
    for(i=0; i<tables.length; i++) 
    {
        tables[i] = safeGetElementById("Tab:"+svgObjectNames[i]);
    }

    /*------- style sheet rules ---------*/
    var ss = document.styleSheets[0];
    ssrules = ss.cssRules ? ss.cssRules : ss.rules; 

    /*------- checkboxes[a] is (expected to be) of class HTMLInputElement ---*/
    for(a=0; a<checkboxes.length; a++)
    {
	checkboxes[a].checked = highlightInitial[a];
        status = checkboxes[a].checked; 
        setReportObj(a+1, status, false);
    }

}


function safeGetElementById(id)
{
    res = document.getElementById(id);
    if(res == null)
        throw new Error("Id '"+ id + "' not found.");
    return(res)
}

/*------------------------------------------------------------
   Highlighting of Report Objects 
 ---------------------------------------------------------------*/
function setReportObj(reportObjId, status, doTable)
{
    var i, j, plotObjIds, selector;

    if(doTable) {
	for(i=0; i<svgObjectNames.length; i++) {
	    showTipTable(i, reportObjId);
	} 
    }

    /* This works in Chrome 10, ssrules will be null; we use getElementsByClassName and loop over them */
    if(ssrules == null) {
	elements = document.getElementsByClassName("aqm" + reportObjId); 
	for(i=0; i<elements.length; i++) {
	    elements[i].style.cssText = cssText[0+status];
	}
    } else {
    /* This works in Firefox 4 */
    for(i=0; i<ssrules.length; i++) {
        if (ssrules[i].selectorText == (".aqm" + reportObjId)) {
		ssrules[i].style.cssText = cssText[0+status];
		break;
	    }
	}
    }

}

/*------------------------------------------------------------
   Display of the Metadata Table
  ------------------------------------------------------------*/
function showTipTable(tableIndex, reportObjId)
{
    var rows = tables[tableIndex].rows;
    var a = reportObjId - 1;

    if(rows.length != arrayMetadata[a].length)
	throw new Error("rows.length=" + rows.length+"  !=  arrayMetadata[array].length=" + arrayMetadata[a].length);

    for(i=0; i<rows.length; i++) 
 	rows[i].cells[1].innerHTML = arrayMetadata[a][i];
}

function hideTipTable(tableIndex)
{
    var rows = tables[tableIndex].rows;

    for(i=0; i<rows.length; i++) 
 	rows[i].cells[1].innerHTML = "";
}


/*------------------------------------------------------------
  From module 'name' (e.g. 'density'), find numeric index in the 
  'svgObjectNames' array.
  ------------------------------------------------------------*/
function getIndexFromName(name) 
{
    var i;
    for(i=0; i<svgObjectNames.length; i++)
        if(svgObjectNames[i] == name)
	    return i;

    throw new Error("Did not find '" + name + "'.");
}


/*------------------------------------------------------------
  SVG plot object callbacks
  ------------------------------------------------------------*/
function plotObjRespond(what, reportObjId, name)
{

    var a, i, status;

    switch(what) {
    case "show":
	i = getIndexFromName(name);
	showTipTable(i, reportObjId);
	break;
    case "hide":
	i = getIndexFromName(name);
	hideTipTable(i);
	break;
    case "click":
        a = reportObjId - 1;
	status = !checkboxes[a].checked;
	checkboxes[a].checked = status;
	setReportObj(reportObjId, status, true);
	break;
    default:
	throw new Error("Invalid 'what': "+what)
    }
}

/*------------------------------------------------------------
  checkboxes 'onchange' event
------------------------------------------------------------*/
function checkboxEvent(reportObjId)
{
    var a = reportObjId - 1;
    var status = checkboxes[a].checked;
    setReportObj(reportObjId, status, true);
}


/*------------------------------------------------------------
  toggle visibility
------------------------------------------------------------*/
function toggle(id){
  var head = safeGetElementById(id + "-h");
  var body = safeGetElementById(id + "-b");
  var hdtxt = head.innerHTML;
  var dsp;
  switch(body.style.display){
    case 'none':
      dsp = 'block';
      hdtxt = '-' + hdtxt.substr(1);
      break;
    case 'block':
      dsp = 'none';
      hdtxt = '+' + hdtxt.substr(1);
      break;
  }  
  body.style.display = dsp;
  head.innerHTML = hdtxt;
}
