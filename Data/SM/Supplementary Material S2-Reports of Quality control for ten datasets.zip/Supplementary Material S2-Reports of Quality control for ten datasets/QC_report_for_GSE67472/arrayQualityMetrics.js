// (C) Wolfgang Huber 2010-2011

// Script parameters - these are set up by R in the function 'writeReport' when copying the 
//   template for this script from arrayQualityMetrics/inst/scripts into the report.

var highlightInitial = [ false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false ];
var arrayMetadata    = [ [ "1", "GSM1647628_08.Fahy_12GOBMUC2_A.CEL.gz", "1", "06/24/04 15:35:15" ], [ "2", "GSM1647629_49.Fahy_13GOBMUC2_A.CEL.gz", "2", "08/03/04 12:14:46" ], [ "3", "GSM1647630_127.Fahy_ma137_EpiBrush.CEL.gz", "3", "12/15/04 15:25:34" ], [ "4", "GSM1647631_99.Fahy_ma117f_EpiBrush.CEL.gz", "4", "09/15/04 16:59:18" ], [ "5", "GSM1647632_50.Fahy_18GOBMUC2_A.CEL.gz", "5", "08/03/04 12:27:47" ], [ "6", "GSM1647633_20.Fahy_19GOBMUC2_N.CEL.gz", "6", "07/14/04 18:31:00" ], [ "7", "GSM1647634_86.Fahy_ma104f_EpiBrush.CEL.gz", "7", "09/14/04 17:04:23" ], [ "8", "GSM1647635_51.Fahy_21GOBMUC2_N.CEL.gz", "8", "08/03/04 12:40:49" ], [ "9", "GSM1647636_75.Fahy_22GOBMUC2_N.CEL.gz", "9", "08/11/04 16:23:41" ], [ "10", "GSM1647637_09.Fahy_23GOBMUC2_N.CEL.gz", "10", "06/24/04 15:47:56" ], [ "11", "GSM1647638_27.Fahy_26GOBMUC2_N.CEL.gz", "11", "07/15/04 16:34:15" ], [ "12", "GSM1647639_21.Fahy_27GOBMUC2_N.CEL.gz", "12", "07/14/04 18:45:04" ], [ "13", "GSM1647640_39.Fahy_28GOBMUC2_A.CEL.gz", "13", "07/28/04 17:09:07" ], [ "14", "GSM1647641_105.Fahy_118f_EpiBrush.CEL.gz", "14", "10/05/04 13:07:26" ], [ "15", "GSM1647642_87.Fahy_ma105f_EpiBrush.CEL.gz", "15", "09/14/04 17:22:34" ], [ "16", "GSM1647643_60.Fahy_34GOBMUC2_N.CEL.gz", "16", "08/03/04 16:40:06" ], [ "17", "GSM1647644_61.Fahy_38GOBMUC2_N.CEL.gz", "17", "08/03/04 16:57:29" ], [ "18", "GSM1647645_62.Fahy_39GOBMUC2_A.CEL.gz", "18", "08/03/04 17:12:30" ], [ "19", "GSM1647646_33.Fahy_1SAGE_A1.CEL.gz", "19", "07/28/04 15:25:27" ], [ "20", "GSM1647647_28.Fahy_2SAGE_A1.CEL.gz", "20", "07/28/04 12:43:33" ], [ "21", "GSM1647648_88.Fahy_ma106f_EpiBrush.CEL.gz", "21", "09/15/04 13:01:35" ], [ "22", "GSM1647649_11.Fahy_4SAGE_A1.CEL.gz", "22", "07/14/04 13:43:09" ], [ "23", "GSM1647650_52.Fahy_5SAGE_A1.CEL.gz", "23", "08/03/04 13:37:19" ], [ "24", "GSM1647651_107.Fahy_120f_EpiBrush.CEL.gz", "24", "10/05/04 14:11:13" ], [ "25", "GSM1647652_04.Fahy_8SAGE_A.CEL.gz", "25", "06/24/04 14:14:04" ], [ "26", "GSM1647653_12.Fahy_9SAGE_A1.CEL.gz", "26", "07/14/04 13:55:50" ], [ "27", "GSM1647654_14.Fahy_10SAGE_A1.CEL.gz", "27", "07/14/04 15:16:34" ], [ "28", "GSM1647655_36.Fahy_11SAGE_A2.CEL.gz", "28", "07/28/04 16:24:15" ], [ "29", "GSM1647656_40.Fahy_15SAGE_A1.CEL.gz", "29", "07/30/04 12:30:41" ], [ "30", "GSM1647657_64.Fahy_16Sage_A1.CEL.gz", "30", "08/11/04 12:19:32" ], [ "31", "GSM1647658_42.Fahy_18SAGE_A1.CEL.gz", "31", "07/30/04 12:44:36" ], [ "32", "GSM1647659_67.Fahy_19Sage_A1.CEL.gz", "32", "08/11/04 12:58:44" ], [ "33", "GSM1647660_76.Fahy_ma94f_EpiBrush.CEL.gz", "33", "09/14/04 12:42:50" ], [ "34", "GSM1647661_29.Fahy_22SAGE_A.CEL.gz", "34", "07/28/04 12:56:50" ], [ "35", "GSM1647662_100.Fahy_ma38_EpiBrush.CEL.gz", "35", "09/28/04 17:16:24" ], [ "36", "GSM1647663_54.Fahy_27SAGE_A1.CEL.gz", "36", "08/03/04 14:03:22" ], [ "37", "GSM1647664_91.Fahy_ma109f_EpiBrush.CEL.gz", "37", "09/15/04 13:48:44" ], [ "38", "GSM1647665_102.Fahy_40f_EpiBrush.CEL.gz", "38", "10/05/04 12:27:46" ], [ "39", "GSM1647666_68.Fahy_32Sage_A1.CEL.gz", "39", "08/11/04 14:00:26" ], [ "40", "GSM1647667_78.Fahy_ma96f_EpiBrush.CEL.gz", "40", "09/14/04 13:11:11" ], [ "41", "GSM1647668_80.Fahy_ma98f_EpiBrush.CEL.gz", "41", "09/14/04 15:09:13" ], [ "42", "GSM1647669_82.Fahy_ma100f_EpiBrush.CEL.gz", "42", "09/14/04 15:38:11" ], [ "43", "GSM1647670_45.Fahy_39SAGE_A1.CEL.gz", "43", "07/30/04 13:55:14" ], [ "44", "GSM1647671_17.Fahy_40SAGE_A1.CEL.gz", "44", "07/14/04 16:09:58" ], [ "45", "GSM1647672_38.Fahy_41SAGE_A1.CEL.gz", "45", "07/28/04 16:53:15" ], [ "46", "GSM1647673_23.Fahy_43SAGE_A1.CEL.gz", "46", "07/15/04 13:03:11" ], [ "47", "GSM1647674_25.Fahy_47SAGE_A1.CEL.gz", "47", "07/15/04 13:28:27" ], [ "48", "GSM1647675_114.Fahy_ma127_EpiBrush.CEL.gz", "48", "09/28/04 17:49:52" ], [ "49", "GSM1647676_123.Fahy_ma144_EpiBrush.CEL.gz", "49", "12/15/04 13:43:34" ], [ "50", "GSM1647677_110.Fahy_123f_EpiBrush.CEL.gz", "50", "10/05/04 15:42:16" ], [ "51", "GSM1647678_84.Fahy_ma102f_EpiBrush.CEL.gz", "51", "09/14/04 16:38:32" ], [ "52", "GSM1647679_57.Fahy_27SMOKE_N.CEL.gz", "52", "08/03/04 15:36:13" ], [ "53", "GSM1647680_58.Fahy_33SMOKE_N.CEL.gz", "53", "08/03/04 15:05:33" ], [ "54", "GSM1647681_46.Fahy_36SMOKE_N.CEL.gz", "54", "07/30/04 14:21:31" ], [ "55", "GSM1647682_07.Fahy_38SMOKE_N.CEL.gz", "55", "06/24/04 14:54:05" ], [ "56", "GSM1647683_93.Fahy_ma111f_EpiBrush.CEL.gz", "56", "09/15/04 15:25:38" ], [ "57", "GSM1647684_70.Fahy_43Smoke_N.CEL.gz", "57", "08/11/04 14:29:17" ], [ "58", "GSM1647685_47.Fahy_44SMOKE_N.CEL.gz", "58", "07/30/04 14:34:28" ], [ "59", "GSM1647686_48.Fahy_57SMOKE_N.CEL.gz", "59", "08/03/04 11:59:40" ], [ "60", "GSM1647687_119.Fahy_ma30_EpiBrush.CEL.gz", "60", "10/05/04 17:59:16" ], [ "61", "GSM1647688_128.Fahy_ma136_EpiBrush.CEL.gz", "61", "12/15/04 16:18:30" ], [ "62", "GSM1647689_111.Fahy_124f_EpiBrush.CEL.gz", "62", "10/05/04 15:55:22" ], [ "63", "GSM1647690_268.CEL.gz", "63", "2011-04-13T17:08:16Z" ], [ "64", "GSM1647691_269.CEL.gz", "64", "2011-04-13T17:20:18Z" ], [ "65", "GSM1647692_270.CEL.gz", "65", "2011-04-13T17:32:06Z" ], [ "66", "GSM1647693_271.CEL.gz", "66", "2011-04-13T17:43:43Z" ], [ "67", "GSM1647694_272.CEL.gz", "67", "2011-04-13T17:55:22Z" ], [ "68", "GSM1647695_273.CEL.gz", "68", "2011-04-13T18:07:00Z" ], [ "69", "GSM1647696_275.CEL.gz", "69", "2011-04-13T18:30:21Z" ], [ "70", "GSM1647697_278A_2.CEL.gz", "70", "2011-05-05T20:09:07Z" ], [ "71", "GSM1647698_280.CEL.gz", "71", "2011-04-13T19:34:20Z" ], [ "72", "GSM1647699_281.CEL.gz", "72", "2011-04-13T19:45:51Z" ], [ "73", "GSM1647700_283.CEL.gz", "73", "2011-04-13T20:08:47Z" ], [ "74", "GSM1647701_354.CEL.gz", "74", "2011-12-02T20:31:58Z" ], [ "75", "GSM1647702_355.CEL.gz", "75", "2011-12-02T18:23:50Z" ], [ "76", "GSM1647703_356.CEL.gz", "76", "2011-12-02T18:35:17Z" ], [ "77", "GSM1647704_359.CEL.gz", "77", "2011-12-02T19:09:28Z" ], [ "78", "GSM1647705_361.CEL.gz", "78", "2011-12-02T19:32:17Z" ], [ "79", "GSM1647706_363.CEL.gz", "79", "2011-12-02T19:55:09Z" ], [ "80", "GSM1647707_365.CEL.gz", "80", "2011-12-02T20:43:19Z" ], [ "81", "GSM1647708_367.CEL.gz", "81", "2011-12-02T21:06:05Z" ], [ "82", "GSM1647709_097.CEL.gz", "82", "2009-12-16T18:48:28Z" ], [ "83", "GSM1647710_101.CEL.gz", "83", "2009-12-16T19:34:54Z" ], [ "84", "GSM1647711_102.CEL.gz", "84", "2009-12-16T19:46:37Z" ], [ "85", "GSM1647712_103.CEL.gz", "85", "2009-12-16T19:58:12Z" ], [ "86", "GSM1647713_104.CEL.gz", "86", "2009-12-16T20:09:37Z" ], [ "87", "GSM1647714_105.CEL.gz", "87", "2009-12-16T20:31:30Z" ], [ "88", "GSM1647715_106.CEL.gz", "88", "2009-12-16T20:42:47Z" ], [ "89", "GSM1647716_107.CEL.gz", "89", "2009-12-16T20:54:28Z" ], [ "90", "GSM1647717_109.CEL.gz", "90", "2009-12-16T22:50:29Z" ], [ "91", "GSM1647718_191.CEL.gz", "91", "2010-03-05T22:35:15Z" ], [ "92", "GSM1647719_192.CEL.gz", "92", "2010-03-05T22:46:53Z" ], [ "93", "GSM1647720_193.CEL.gz", "93", "2010-03-05T22:58:26Z" ], [ "94", "GSM1647721_194.CEL.gz", "94", "2010-03-05T23:09:52Z" ], [ "95", "GSM1647722_197.CEL.gz", "95", "2010-03-05T23:53:52Z" ], [ "96", "GSM1647723_199.CEL.gz", "96", "2010-03-05T21:49:53Z" ], [ "97", "GSM1647724_200.CEL.gz", "97", "2010-03-05T23:30:53Z" ], [ "98", "GSM1647725_202.CEL.gz", "98", "2010-03-05T22:01:15Z" ], [ "99", "GSM1647726_204.CEL.gz", "99", "2010-03-06T00:51:13Z" ], [ "100", "GSM1647727_231_new.CEL.gz", "100", "2010-10-28T18:36:24Z" ], [ "101", "GSM1647728_232_new.CEL.gz", "101", "2010-10-28T18:48:09Z" ], [ "102", "GSM1647729_233_new.CEL.gz", "102", "2010-10-28T18:59:50Z" ], [ "103", "GSM1647730_235_new.CEL.gz", "103", "2010-10-28T19:23:21Z" ], [ "104", "GSM1647731_237_new.CEL.gz", "104", "2010-10-28T19:46:36Z" ], [ "105", "GSM1647732_239_new.CEL.gz", "105", "2010-10-28T20:26:33Z" ] ];
var svgObjectNames   = [ "pca", "dens" ];

var cssText = ["stroke-width:1; stroke-opacity:0.4",
               "stroke-width:3; stroke-opacity:1" ];

// Global variables - these are set up below by 'reportinit'
var tables;             // array of all the associated ('tooltips') tables on the page
var checkboxes;         // the checkboxes
var ssrules;


function reportinit() 
{
 
    var a, i, status;

    /*--------find checkboxes and set them to start values------*/
    checkboxes = document.getElementsByName("ReportObjectCheckBoxes");
    if(checkboxes.length != highlightInitial.length)
	throw new Error("checkboxes.length=" + checkboxes.length + "  !=  "
                        + " highlightInitial.length="+ highlightInitial.length);
    
    /*--------find associated tables and cache their locations------*/
    tables = new Array(svgObjectNames.length);
    for(i=0; i<tables.length; i++) 
    {
        tables[i] = safeGetElementById("Tab:"+svgObjectNames[i]);
    }

    /*------- style sheet rules ---------*/
    var ss = document.styleSheets[0];
    ssrules = ss.cssRules ? ss.cssRules : ss.rules; 

    /*------- checkboxes[a] is (expected to be) of class HTMLInputElement ---*/
    for(a=0; a<checkboxes.length; a++)
    {
	checkboxes[a].checked = highlightInitial[a];
        status = checkboxes[a].checked; 
        setReportObj(a+1, status, false);
    }

}


function safeGetElementById(id)
{
    res = document.getElementById(id);
    if(res == null)
        throw new Error("Id '"+ id + "' not found.");
    return(res)
}

/*------------------------------------------------------------
   Highlighting of Report Objects 
 ---------------------------------------------------------------*/
function setReportObj(reportObjId, status, doTable)
{
    var i, j, plotObjIds, selector;

    if(doTable) {
	for(i=0; i<svgObjectNames.length; i++) {
	    showTipTable(i, reportObjId);
	} 
    }

    /* This works in Chrome 10, ssrules will be null; we use getElementsByClassName and loop over them */
    if(ssrules == null) {
	elements = document.getElementsByClassName("aqm" + reportObjId); 
	for(i=0; i<elements.length; i++) {
	    elements[i].style.cssText = cssText[0+status];
	}
    } else {
    /* This works in Firefox 4 */
    for(i=0; i<ssrules.length; i++) {
        if (ssrules[i].selectorText == (".aqm" + reportObjId)) {
		ssrules[i].style.cssText = cssText[0+status];
		break;
	    }
	}
    }

}

/*------------------------------------------------------------
   Display of the Metadata Table
  ------------------------------------------------------------*/
function showTipTable(tableIndex, reportObjId)
{
    var rows = tables[tableIndex].rows;
    var a = reportObjId - 1;

    if(rows.length != arrayMetadata[a].length)
	throw new Error("rows.length=" + rows.length+"  !=  arrayMetadata[array].length=" + arrayMetadata[a].length);

    for(i=0; i<rows.length; i++) 
 	rows[i].cells[1].innerHTML = arrayMetadata[a][i];
}

function hideTipTable(tableIndex)
{
    var rows = tables[tableIndex].rows;

    for(i=0; i<rows.length; i++) 
 	rows[i].cells[1].innerHTML = "";
}


/*------------------------------------------------------------
  From module 'name' (e.g. 'density'), find numeric index in the 
  'svgObjectNames' array.
  ------------------------------------------------------------*/
function getIndexFromName(name) 
{
    var i;
    for(i=0; i<svgObjectNames.length; i++)
        if(svgObjectNames[i] == name)
	    return i;

    throw new Error("Did not find '" + name + "'.");
}


/*------------------------------------------------------------
  SVG plot object callbacks
  ------------------------------------------------------------*/
function plotObjRespond(what, reportObjId, name)
{

    var a, i, status;

    switch(what) {
    case "show":
	i = getIndexFromName(name);
	showTipTable(i, reportObjId);
	break;
    case "hide":
	i = getIndexFromName(name);
	hideTipTable(i);
	break;
    case "click":
        a = reportObjId - 1;
	status = !checkboxes[a].checked;
	checkboxes[a].checked = status;
	setReportObj(reportObjId, status, true);
	break;
    default:
	throw new Error("Invalid 'what': "+what)
    }
}

/*------------------------------------------------------------
  checkboxes 'onchange' event
------------------------------------------------------------*/
function checkboxEvent(reportObjId)
{
    var a = reportObjId - 1;
    var status = checkboxes[a].checked;
    setReportObj(reportObjId, status, true);
}


/*------------------------------------------------------------
  toggle visibility
------------------------------------------------------------*/
function toggle(id){
  var head = safeGetElementById(id + "-h");
  var body = safeGetElementById(id + "-b");
  var hdtxt = head.innerHTML;
  var dsp;
  switch(body.style.display){
    case 'none':
      dsp = 'block';
      hdtxt = '-' + hdtxt.substr(1);
      break;
    case 'block':
      dsp = 'none';
      hdtxt = '+' + hdtxt.substr(1);
      break;
  }  
  body.style.display = dsp;
  head.innerHTML = hdtxt;
}
