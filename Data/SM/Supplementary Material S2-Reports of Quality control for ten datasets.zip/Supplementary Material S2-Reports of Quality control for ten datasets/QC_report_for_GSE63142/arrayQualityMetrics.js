// (C) Wolfgang Huber 2010-2011

// Script parameters - these are set up by R in the function 'writeReport' when copying the 
//   template for this script from arrayQualityMetrics/inst/scripts into the report.

var highlightInitial = [ false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true ];
var arrayMetadata    = [ [ "1", "GSM1541999_1070A.txt" ], [ "2", "GSM1542000_1225D.txt" ], [ "3", "GSM1542001_1546X.txt" ], [ "4", "GSM1542002_1579M.txt" ], [ "5", "GSM1542003_1619Y.txt" ], [ "6", "GSM1542004_1624R.txt" ], [ "7", "GSM1542005_1656E.txt" ], [ "8", "GSM1542006_1701J.txt" ], [ "9", "GSM1542007_1705R.txt" ], [ "10", "GSM1542008_1733W.txt" ], [ "11", "GSM1542009_1734Y.txt" ], [ "12", "GSM1542010_1818E.txt" ], [ "13", "GSM1542011_1878H.txt" ], [ "14", "GSM1542012_1902T.txt" ], [ "15", "GSM1542013_1925F.txt" ], [ "16", "GSM1542014_1943H.txt" ], [ "17", "GSM1542015_2034B.txt" ], [ "18", "GSM1542016_2052D.txt" ], [ "19", "GSM1542017_2096X.txt" ], [ "20", "GSM1542018_2129M.txt" ], [ "21", "GSM1542019_2170J.txt" ], [ "22", "GSM1542020_2244M.txt" ], [ "23", "GSM1542021_2252L.txt" ], [ "24", "GSM1542022_2287E.txt" ], [ "25", "GSM1542023_2295D.txt" ], [ "26", "GSM1542024_2309O.txt" ], [ "27", "GSM1542025_2310Z.txt" ], [ "28", "GSM1542026_0112F.txt" ], [ "29", "GSM1542027_0114X.txt" ], [ "30", "GSM1542028_0154V.txt" ], [ "31", "GSM1542029_0168R.txt" ], [ "32", "GSM1542030_0211F.txt" ], [ "33", "GSM1542031_0308V.txt" ], [ "34", "GSM1542032_0311B.txt" ], [ "35", "GSM1542033_0423C.txt" ], [ "36", "GSM1542034_1005P.txt" ], [ "37", "GSM1542035_1142Z.txt" ], [ "38", "GSM1542036_1273O.txt" ], [ "39", "GSM1542037_1341F.txt" ], [ "40", "GSM1542038_1397G.txt" ], [ "41", "GSM1542039_1691G.txt" ], [ "42", "GSM1542040_1708X.txt" ], [ "43", "GSM1542041_1751Y.txt" ], [ "44", "GSM1542042_1752A.txt" ], [ "45", "GSM1542043_1765J.txt" ], [ "46", "GSM1542044_1774K.txt" ], [ "47", "GSM1542045_1780F.txt" ], [ "48", "GSM1542046_1781H.txt" ], [ "49", "GSM1542047_1784N.txt" ], [ "50", "GSM1542048_1790I.txt" ], [ "51", "GSM1542049_1815Y.txt" ], [ "52", "GSM1542050_1821T.txt" ], [ "53", "GSM1542051_1863J.txt" ], [ "54", "GSM1542052_1908F.txt" ], [ "55", "GSM1542053_1926H.txt" ], [ "56", "GSM1542054_1945L.txt" ], [ "57", "GSM1542055_1958U.txt" ], [ "58", "GSM1542056_1973Q.txt" ], [ "59", "GSM1542057_2001M.txt" ], [ "60", "GSM1542058_2003Q.txt" ], [ "61", "GSM1542059_2012R.txt" ], [ "62", "GSM1542060_2014V.txt" ], [ "63", "GSM1542061_2048M.txt" ], [ "64", "GSM1542062_2063I.txt" ], [ "65", "GSM1542063_2065M.txt" ], [ "66", "GSM1542064_2073L.txt" ], [ "67", "GSM1542065_2079X.txt" ], [ "68", "GSM1542066_2119J.txt" ], [ "69", "GSM1542067_2122Y.txt" ], [ "70", "GSM1542068_2128K.txt" ], [ "71", "GSM1542069_2130X.txt" ], [ "72", "GSM1542070_2131Z.txt" ], [ "73", "GSM1542071_2134F.txt" ], [ "74", "GSM1542072_2139P.txt" ], [ "75", "GSM1542073_2143G.txt" ], [ "76", "GSM1542074_2154L.txt" ], [ "77", "GSM1542075_2156P.txt" ], [ "78", "GSM1542076_2163M.txt" ], [ "79", "GSM1542077_2168W.txt" ], [ "80", "GSM1542078_2183S.txt" ], [ "81", "GSM1542079_2198F.txt" ], [ "82", "GSM1542080_2223E.txt" ], [ "83", "GSM1542081_2224G.txt" ], [ "84", "GSM1542082_2230B.txt" ], [ "85", "GSM1542083_2232F.txt" ], [ "86", "GSM1542084_2237P.txt" ], [ "87", "GSM1542085_2253N.txt" ], [ "88", "GSM1542086_2284Y.txt" ], [ "89", "GSM1542087_2291J.txt" ], [ "90", "GSM1542088_2292X.txt" ], [ "91", "GSM1542089_2301Y.txt" ], [ "92", "GSM1542090_2303C.txt" ], [ "93", "GSM1542091_2305G.txt" ], [ "94", "GSM1542092_2306I.txt" ], [ "95", "GSM1542093_GSK053V4.txt" ], [ "96", "GSM1542094_GSK067V4.txt" ], [ "97", "GSM1542095_GSK068V4.txt" ], [ "98", "GSM1542096_GSK079.txt" ], [ "99", "GSM1542097_GSK082.txt" ], [ "100", "GSM1542098_0497F.txt" ], [ "101", "GSM1542099_0658D.txt" ], [ "102", "GSM1542100_0667E.txt" ], [ "103", "GSM1542101_0828C.txt" ], [ "104", "GSM1542102_1036A.txt" ], [ "105", "GSM1542103_1224B.txt" ], [ "106", "GSM1542104_1389H.txt" ], [ "107", "GSM1542105_1566D.txt" ], [ "108", "GSM1542106_1568H.txt" ], [ "109", "GSM1542107_1578K.txt" ], [ "110", "GSM1542108_1623P.txt" ], [ "111", "GSM1542109_1628Z.txt" ], [ "112", "GSM1542110_1661X.txt" ], [ "113", "GSM1542111_1682F.txt" ], [ "114", "GSM1542112_1683H.txt" ], [ "115", "GSM1542113_1695O.txt" ], [ "116", "GSM1542114_1726Z.txt" ], [ "117", "GSM1542115_1743Z.txt" ], [ "118", "GSM1542116_1744B.txt" ], [ "119", "GSM1542117_1771E.txt" ], [ "120", "GSM1542118_1841Z.txt" ], [ "121", "GSM1542119_1870G.txt" ], [ "122", "GSM1542120_1918I.txt" ], [ "123", "GSM1542121_1921X.txt" ], [ "124", "GSM1542122_1929N.txt" ], [ "125", "GSM1542123_1941D.txt" ], [ "126", "GSM1542124_1964P.txt" ], [ "127", "GSM1542125_1969Z.txt" ], [ "128", "GSM1542126_1970K.txt" ], [ "129", "GSM1542127_1986Z.txt" ], [ "130", "GSM1542128_1989F.txt" ], [ "131", "GSM1542129_1997E.txt" ], [ "132", "GSM1542130_1998G.txt" ], [ "133", "GSM1542131_2016Z.txt" ], [ "134", "GSM1542132_2030T.txt" ], [ "135", "GSM1542133_2040W.txt" ], [ "136", "GSM1542134_2042A.txt" ], [ "137", "GSM1542135_2047K.txt" ], [ "138", "GSM1542136_2102S.txt" ], [ "139", "GSM1542137_2111T.txt" ], [ "140", "GSM1542138_2118H.txt" ], [ "141", "GSM1542139_2136J.txt" ], [ "142", "GSM1542140_2147O.txt" ], [ "143", "GSM1542141_2166S.txt" ], [ "144", "GSM1542142_2177X.txt" ], [ "145", "GSM1542143_2184U.txt" ], [ "146", "GSM1542144_2254P.txt" ], [ "147", "GSM1542145_2261M.txt" ], [ "148", "GSM1542146_2276Z.txt" ], [ "149", "GSM1542147_2278D.txt" ], [ "150", "GSM1542148_2280Q.txt" ], [ "151", "GSM1542149_2288G.txt" ], [ "152", "GSM1542150_2293Z.txt" ], [ "153", "GSM1542151_2314H.txt" ], [ "154", "GSM1542152_GSK047V4.txt" ], [ "155", "GSM1542153_GSK052V4.txt" ] ];
var svgObjectNames   = [ "pca", "dens" ];

var cssText = ["stroke-width:1; stroke-opacity:0.4",
               "stroke-width:3; stroke-opacity:1" ];

// Global variables - these are set up below by 'reportinit'
var tables;             // array of all the associated ('tooltips') tables on the page
var checkboxes;         // the checkboxes
var ssrules;


function reportinit() 
{
 
    var a, i, status;

    /*--------find checkboxes and set them to start values------*/
    checkboxes = document.getElementsByName("ReportObjectCheckBoxes");
    if(checkboxes.length != highlightInitial.length)
	throw new Error("checkboxes.length=" + checkboxes.length + "  !=  "
                        + " highlightInitial.length="+ highlightInitial.length);
    
    /*--------find associated tables and cache their locations------*/
    tables = new Array(svgObjectNames.length);
    for(i=0; i<tables.length; i++) 
    {
        tables[i] = safeGetElementById("Tab:"+svgObjectNames[i]);
    }

    /*------- style sheet rules ---------*/
    var ss = document.styleSheets[0];
    ssrules = ss.cssRules ? ss.cssRules : ss.rules; 

    /*------- checkboxes[a] is (expected to be) of class HTMLInputElement ---*/
    for(a=0; a<checkboxes.length; a++)
    {
	checkboxes[a].checked = highlightInitial[a];
        status = checkboxes[a].checked; 
        setReportObj(a+1, status, false);
    }

}


function safeGetElementById(id)
{
    res = document.getElementById(id);
    if(res == null)
        throw new Error("Id '"+ id + "' not found.");
    return(res)
}

/*------------------------------------------------------------
   Highlighting of Report Objects 
 ---------------------------------------------------------------*/
function setReportObj(reportObjId, status, doTable)
{
    var i, j, plotObjIds, selector;

    if(doTable) {
	for(i=0; i<svgObjectNames.length; i++) {
	    showTipTable(i, reportObjId);
	} 
    }

    /* This works in Chrome 10, ssrules will be null; we use getElementsByClassName and loop over them */
    if(ssrules == null) {
	elements = document.getElementsByClassName("aqm" + reportObjId); 
	for(i=0; i<elements.length; i++) {
	    elements[i].style.cssText = cssText[0+status];
	}
    } else {
    /* This works in Firefox 4 */
    for(i=0; i<ssrules.length; i++) {
        if (ssrules[i].selectorText == (".aqm" + reportObjId)) {
		ssrules[i].style.cssText = cssText[0+status];
		break;
	    }
	}
    }

}

/*------------------------------------------------------------
   Display of the Metadata Table
  ------------------------------------------------------------*/
function showTipTable(tableIndex, reportObjId)
{
    var rows = tables[tableIndex].rows;
    var a = reportObjId - 1;

    if(rows.length != arrayMetadata[a].length)
	throw new Error("rows.length=" + rows.length+"  !=  arrayMetadata[array].length=" + arrayMetadata[a].length);

    for(i=0; i<rows.length; i++) 
 	rows[i].cells[1].innerHTML = arrayMetadata[a][i];
}

function hideTipTable(tableIndex)
{
    var rows = tables[tableIndex].rows;

    for(i=0; i<rows.length; i++) 
 	rows[i].cells[1].innerHTML = "";
}


/*------------------------------------------------------------
  From module 'name' (e.g. 'density'), find numeric index in the 
  'svgObjectNames' array.
  ------------------------------------------------------------*/
function getIndexFromName(name) 
{
    var i;
    for(i=0; i<svgObjectNames.length; i++)
        if(svgObjectNames[i] == name)
	    return i;

    throw new Error("Did not find '" + name + "'.");
}


/*------------------------------------------------------------
  SVG plot object callbacks
  ------------------------------------------------------------*/
function plotObjRespond(what, reportObjId, name)
{

    var a, i, status;

    switch(what) {
    case "show":
	i = getIndexFromName(name);
	showTipTable(i, reportObjId);
	break;
    case "hide":
	i = getIndexFromName(name);
	hideTipTable(i);
	break;
    case "click":
        a = reportObjId - 1;
	status = !checkboxes[a].checked;
	checkboxes[a].checked = status;
	setReportObj(reportObjId, status, true);
	break;
    default:
	throw new Error("Invalid 'what': "+what)
    }
}

/*------------------------------------------------------------
  checkboxes 'onchange' event
------------------------------------------------------------*/
function checkboxEvent(reportObjId)
{
    var a = reportObjId - 1;
    var status = checkboxes[a].checked;
    setReportObj(reportObjId, status, true);
}


/*------------------------------------------------------------
  toggle visibility
------------------------------------------------------------*/
function toggle(id){
  var head = safeGetElementById(id + "-h");
  var body = safeGetElementById(id + "-b");
  var hdtxt = head.innerHTML;
  var dsp;
  switch(body.style.display){
    case 'none':
      dsp = 'block';
      hdtxt = '-' + hdtxt.substr(1);
      break;
    case 'block':
      dsp = 'none';
      hdtxt = '+' + hdtxt.substr(1);
      break;
  }  
  body.style.display = dsp;
  head.innerHTML = hdtxt;
}
