// (C) Wolfgang Huber 2010-2011

// Script parameters - these are set up by R in the function 'writeReport' when copying the 
//   template for this script from arrayQualityMetrics/inst/scripts into the report.

var highlightInitial = [ false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false, true, true, false, false ];
var arrayMetadata    = [ [ "1", "GSM1583183_Sample_2.CEL.gz", "1", "2011-10-19T15:46:27Z" ], [ "2", "GSM1583184_Sample_3.CEL.gz", "2", "2011-10-19T17:49:25Z" ], [ "3", "GSM1583185_Sample_4.CEL.gz", "3", "2011-10-19T16:30:54Z" ], [ "4", "GSM1583186_Sample_5.CEL.gz", "4", "2011-10-19T16:42:08Z" ], [ "5", "GSM1583187_Sample_6.CEL.gz", "5", "2011-10-19T14:38:10Z" ], [ "6", "GSM1583188_Sample_7.CEL.gz", "6", "2011-10-19T18:34:42Z" ], [ "7", "GSM1583189_Sample_8.CEL.gz", "7", "2011-10-19T14:15:56Z" ], [ "8", "GSM1583191_Sample_10.CEL.gz", "8", "2011-10-19T21:23:56Z" ], [ "9", "GSM1583192_Sample_11.CEL.gz", "9", "2011-10-19T15:00:14Z" ], [ "10", "GSM1583193_Sample_12.CEL.gz", "10", "2011-10-19T19:52:48Z" ], [ "11", "GSM1583194_Sample_13.CEL.gz", "11", "2012-05-09T16:46:42Z" ], [ "12", "GSM1583195_Sample_14.CEL.gz", "12", "2012-05-09T23:54:18Z" ], [ "13", "GSM1583196_Sample_15.CEL.gz", "13", "2012-05-09T13:41:52Z" ], [ "14", "GSM1583197_Sample_16.CEL.gz", "14", "2012-05-09T22:46:47Z" ], [ "15", "GSM1583198_Sample_17.CEL.gz", "15", "2012-05-09T18:26:50Z" ], [ "16", "GSM1583200_Sample_19.CEL.gz", "16", "2012-05-09T22:58:05Z" ], [ "17", "GSM1583201_Sample_20.CEL.gz", "17", "2012-05-09T16:23:58Z" ], [ "18", "GSM1583202_Sample_21.CEL.gz", "18", "2012-05-09T19:00:45Z" ], [ "19", "GSM1583203_Sample_22.CEL.gz", "19", "2011-10-19T17:04:38Z" ], [ "20", "GSM1583204_Sample_23.CEL.gz", "20", "2011-10-19T19:19:07Z" ], [ "21", "GSM1583205_Sample_24.CEL.gz", "21", "2011-10-19T16:19:47Z" ], [ "22", "GSM1583206_Sample_25.CEL.gz", "22", "2011-10-19T21:57:09Z" ], [ "23", "GSM1583207_Sample_26.CEL.gz", "23", "2011-10-19T13:53:51Z" ], [ "24", "GSM1583208_Sample_27.CEL.gz", "24", "2011-10-19T18:57:08Z" ], [ "25", "GSM1583209_Sample_28.CEL.gz", "25", "2011-10-19T23:26:30Z" ], [ "26", "GSM1583210_Sample_29.CEL.gz", "26", "2011-10-19T23:37:57Z" ], [ "27", "GSM1583211_Sample_30.CEL.gz", "27", "2011-10-19T14:04:58Z" ], [ "28", "GSM1583212_Sample_31.CEL.gz", "28", "2011-10-19T14:49:06Z" ], [ "29", "GSM1583214_Sample_33.CEL.gz", "29", "2012-05-09T23:31:43Z" ], [ "30", "GSM1583215_Sample_34.CEL.gz", "30", "2012-05-10T00:51:05Z" ], [ "31", "GSM1583216_Sample_35.CEL.gz", "31", "2012-05-09T22:24:15Z" ], [ "32", "GSM1583218_Sample_37.CEL.gz", "32", "2012-05-09T20:30:58Z" ], [ "33", "GSM1583219_Sample_38.CEL.gz", "33", "2012-05-09T22:01:36Z" ], [ "34", "GSM1583220_Sample_39.CEL.gz", "34", "2012-05-09T13:30:29Z" ], [ "35", "GSM1583221_Sample_40.CEL.gz", "35", "2012-05-09T18:49:29Z" ], [ "36", "GSM1583222_Sample_41.CEL.gz", "36", "2011-10-19T17:15:50Z" ], [ "37", "GSM1583223_Sample_42.CEL.gz", "37", "2011-10-19T19:08:05Z" ], [ "38", "GSM1583224_Sample_43.CEL.gz", "38", "2011-10-19T20:16:44Z" ], [ "39", "GSM1583225_Sample_44.CEL.gz", "39", "2011-10-19T23:15:15Z" ], [ "40", "GSM1583226_Sample_45.CEL.gz", "40", "2011-10-19T21:34:57Z" ], [ "41", "GSM1583227_Sample_46.CEL.gz", "41", "2011-10-19T15:11:16Z" ], [ "42", "GSM1583229_Sample_48.CEL.gz", "42", "2011-10-19T17:38:06Z" ], [ "43", "GSM1583231_Sample_50.CEL.gz", "43", "2011-10-19T20:50:13Z" ], [ "44", "GSM1583232_Sample_51.CEL.gz", "44", "2011-10-19T22:19:20Z" ], [ "45", "GSM1583233_Sample_52.CEL.gz", "45", "2012-05-09T16:35:25Z" ], [ "46", "GSM1583234_Sample_53.CEL.gz", "46", "2012-05-09T19:22:51Z" ], [ "47", "GSM1583235_Sample_54.CEL.gz", "47", "2012-05-09T18:15:34Z" ], [ "48", "GSM1583236_Sample_55.CEL.gz", "48", "2012-05-09T20:53:26Z" ], [ "49", "GSM1583237_Sample_56.CEL.gz", "49", "2011-10-20T00:11:28Z" ], [ "50", "GSM1583238_Sample_57.CEL.gz", "50", "2011-10-19T23:49:02Z" ], [ "51", "GSM1583239_Sample_58.CEL.gz", "51", "2011-10-19T14:26:57Z" ], [ "52", "GSM1583240_Sample_59.CEL.gz", "52", "2011-10-19T19:41:45Z" ], [ "53", "GSM1583242_Sample_61.CEL.gz", "53", "2011-10-19T20:38:56Z" ], [ "54", "GSM1583244_Sample_63.CEL.gz", "54", "2011-10-19T21:12:59Z" ], [ "55", "GSM1583245_Sample_64.CEL.gz", "55", "2011-10-19T22:30:39Z" ], [ "56", "GSM1583247_Sample_66.CEL.gz", "56", "2011-10-19T22:08:20Z" ], [ "57", "GSM1583249_Sample_68.CEL.gz", "57", "2012-05-09T19:11:55Z" ], [ "58", "GSM1583250_Sample_69.CEL.gz", "58", "2012-05-09T15:48:12Z" ], [ "59", "GSM1583251_Sample_70.CEL.gz", "59", "2012-05-09T15:25:33Z" ] ];
var svgObjectNames   = [ "pca", "dens" ];

var cssText = ["stroke-width:1; stroke-opacity:0.4",
               "stroke-width:3; stroke-opacity:1" ];

// Global variables - these are set up below by 'reportinit'
var tables;             // array of all the associated ('tooltips') tables on the page
var checkboxes;         // the checkboxes
var ssrules;


function reportinit() 
{
 
    var a, i, status;

    /*--------find checkboxes and set them to start values------*/
    checkboxes = document.getElementsByName("ReportObjectCheckBoxes");
    if(checkboxes.length != highlightInitial.length)
	throw new Error("checkboxes.length=" + checkboxes.length + "  !=  "
                        + " highlightInitial.length="+ highlightInitial.length);
    
    /*--------find associated tables and cache their locations------*/
    tables = new Array(svgObjectNames.length);
    for(i=0; i<tables.length; i++) 
    {
        tables[i] = safeGetElementById("Tab:"+svgObjectNames[i]);
    }

    /*------- style sheet rules ---------*/
    var ss = document.styleSheets[0];
    ssrules = ss.cssRules ? ss.cssRules : ss.rules; 

    /*------- checkboxes[a] is (expected to be) of class HTMLInputElement ---*/
    for(a=0; a<checkboxes.length; a++)
    {
	checkboxes[a].checked = highlightInitial[a];
        status = checkboxes[a].checked; 
        setReportObj(a+1, status, false);
    }

}


function safeGetElementById(id)
{
    res = document.getElementById(id);
    if(res == null)
        throw new Error("Id '"+ id + "' not found.");
    return(res)
}

/*------------------------------------------------------------
   Highlighting of Report Objects 
 ---------------------------------------------------------------*/
function setReportObj(reportObjId, status, doTable)
{
    var i, j, plotObjIds, selector;

    if(doTable) {
	for(i=0; i<svgObjectNames.length; i++) {
	    showTipTable(i, reportObjId);
	} 
    }

    /* This works in Chrome 10, ssrules will be null; we use getElementsByClassName and loop over them */
    if(ssrules == null) {
	elements = document.getElementsByClassName("aqm" + reportObjId); 
	for(i=0; i<elements.length; i++) {
	    elements[i].style.cssText = cssText[0+status];
	}
    } else {
    /* This works in Firefox 4 */
    for(i=0; i<ssrules.length; i++) {
        if (ssrules[i].selectorText == (".aqm" + reportObjId)) {
		ssrules[i].style.cssText = cssText[0+status];
		break;
	    }
	}
    }

}

/*------------------------------------------------------------
   Display of the Metadata Table
  ------------------------------------------------------------*/
function showTipTable(tableIndex, reportObjId)
{
    var rows = tables[tableIndex].rows;
    var a = reportObjId - 1;

    if(rows.length != arrayMetadata[a].length)
	throw new Error("rows.length=" + rows.length+"  !=  arrayMetadata[array].length=" + arrayMetadata[a].length);

    for(i=0; i<rows.length; i++) 
 	rows[i].cells[1].innerHTML = arrayMetadata[a][i];
}

function hideTipTable(tableIndex)
{
    var rows = tables[tableIndex].rows;

    for(i=0; i<rows.length; i++) 
 	rows[i].cells[1].innerHTML = "";
}


/*------------------------------------------------------------
  From module 'name' (e.g. 'density'), find numeric index in the 
  'svgObjectNames' array.
  ------------------------------------------------------------*/
function getIndexFromName(name) 
{
    var i;
    for(i=0; i<svgObjectNames.length; i++)
        if(svgObjectNames[i] == name)
	    return i;

    throw new Error("Did not find '" + name + "'.");
}


/*------------------------------------------------------------
  SVG plot object callbacks
  ------------------------------------------------------------*/
function plotObjRespond(what, reportObjId, name)
{

    var a, i, status;

    switch(what) {
    case "show":
	i = getIndexFromName(name);
	showTipTable(i, reportObjId);
	break;
    case "hide":
	i = getIndexFromName(name);
	hideTipTable(i);
	break;
    case "click":
        a = reportObjId - 1;
	status = !checkboxes[a].checked;
	checkboxes[a].checked = status;
	setReportObj(reportObjId, status, true);
	break;
    default:
	throw new Error("Invalid 'what': "+what)
    }
}

/*------------------------------------------------------------
  checkboxes 'onchange' event
------------------------------------------------------------*/
function checkboxEvent(reportObjId)
{
    var a = reportObjId - 1;
    var status = checkboxes[a].checked;
    setReportObj(reportObjId, status, true);
}


/*------------------------------------------------------------
  toggle visibility
------------------------------------------------------------*/
function toggle(id){
  var head = safeGetElementById(id + "-h");
  var body = safeGetElementById(id + "-b");
  var hdtxt = head.innerHTML;
  var dsp;
  switch(body.style.display){
    case 'none':
      dsp = 'block';
      hdtxt = '-' + hdtxt.substr(1);
      break;
    case 'block':
      dsp = 'none';
      hdtxt = '+' + hdtxt.substr(1);
      break;
  }  
  body.style.display = dsp;
  head.innerHTML = hdtxt;
}
