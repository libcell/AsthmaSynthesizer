// (C) Wolfgang Huber 2010-2011

// Script parameters - these are set up by R in the function 'writeReport' when copying the 
//   template for this script from arrayQualityMetrics/inst/scripts into the report.

var highlightInitial = [ false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, true, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, true, true, true, true, true, false, true, false, false, false, false, false, false, false, false ];
var arrayMetadata    = [ [ "1", "GSM1026490_AA-002_OFF_MILD-INT_POS_PRLL.CEL.gz", "1", "01/04/11 13:33:53" ], [ "2", "GSM1026491_AA-003_OFF_MOD-PER_POS_PRLL.CEL.gz", "2", "01/04/11 12:26:08" ], [ "3", "GSM1026492_AA-004_OFF_MILD-INT_POS_PRLL.CEL.gz", "3", "01/04/11 13:11:16" ], [ "4", "GSM1026493_AA-005_NS_NEG_PLLL.CEL.gz", "4", "03/17/11 16:00:04" ], [ "5", "GSM1026494_AA-006_NS_NEG_PLLL.CEL.gz", "5", "03/17/11 14:53:28" ], [ "6", "GSM1026495_AA-007_NS_NEG_PRLL.CEL.gz", "6", "03/30/11 14:08:07" ], [ "7", "GSM1026496_AA-008_OFF_MILD-INT_POS_PRLL.CEL.gz", "7", "04/01/11 12:07:08" ], [ "8", "GSM1026497_AA-009_NS_NEG_PLLL.CEL.gz", "8", "04/15/11 13:46:50" ], [ "9", "GSM1026498_AA-010_NS_NEG_PRLL.CEL.gz", "9", "04/15/11 12:20:08" ], [ "10", "GSM1026499_AA-012_ON_SEVERE-PER_POS_PLLL.CEL.gz", "10", "05/13/11 17:23:09" ], [ "11", "GSM1026500_AA-013_OFF_MILD-PER_POS_PLLL.CEL.gz", "11", "06/21/11 13:05:07" ], [ "12", "GSM1026501_AA-014_OFF_SEVERE-PER_POS_PLLL.CEL.gz", "12", "06/21/11 13:26:32" ], [ "13", "GSM1026502_AA-015_NS_NEG_PLLL.CEL.gz", "13", "06/21/11 13:48:10" ], [ "14", "GSM1026503_AA-016_NS_NEG_PLLL.CEL.gz", "14", "08/16/11 13:56:10" ], [ "15", "GSM1026504_AA-017_ON_MOD-PER_POS_PRLL.CEL.gz", "15", "06/21/11 14:09:43" ], [ "16", "GSM1026505_AA-018_OFF_SEVERE-PER_POS_PLLL.CEL.gz", "16", "07/12/11 12:16:01" ], [ "17", "GSM1026506_AA-019_ON_MOD-PER_POS_PRLL.CEL.gz", "17", "07/12/11 13:42:28" ], [ "18", "GSM1026507_AA-020_OFF_MILD-PER_POS_PLLL.CEL.gz", "18", "07/22/11 13:07:38" ], [ "19", "GSM1026508_AA-021_OFF_MILD-INT_POS_PRLL.CEL.gz", "19", "07/22/11 12:35:13" ], [ "20", "GSM1026509_AA-022_OFF_MILD-PER_POS_PLLL.CEL.gz", "20", "07/22/11 12:03:07" ], [ "21", "GSM1026510_AA-023_ON_MOD-PER_POS_PRLL.CEL.gz", "21", "08/04/11 11:54:56" ], [ "22", "GSM1026511_AA-024_ON_MOD-PER_POS_PRLL.CEL.gz", "22", "08/16/11 14:29:19" ], [ "23", "GSM1026512_AA-025_ON_MILD-PER_POS_PLLL.CEL.gz", "23", "08/16/11 13:45:00" ], [ "24", "GSM1026513_AA-026_OFF_MILD-PER_POS_PLLL.CEL.gz", "24", "08/20/11 14:04:49" ], [ "25", "GSM1026514_AA-028_OFF_MILD-PER_POS_PRLL.CEL.gz", "25", "09/02/11 13:39:06" ], [ "26", "GSM1026515_AA-029_OFF_MILD-INT_POS_PLLL.CEL.gz", "26", "09/02/11 13:28:01" ], [ "27", "GSM1026516_AA-030_NS_NEG_PLLL.CEL.gz", "27", "11/01/11 12:01:49" ], [ "28", "GSM1026517_AA-031_NS_NEG_PRLL.CEL.gz", "28", "10/28/11 13:23:22" ], [ "29", "GSM1026518_AA-032_NS_NEG_PLLL.CEL.gz", "29", "10/28/11 12:38:09" ], [ "30", "GSM1026519_AA-034_OFF_MILD-PER_POS_PLLL.CEL.gz", "30", "11/01/11 14:04:50" ], [ "31", "GSM1026520_AA-035_NS_NEG_PRLL.CEL.gz", "31", "11/03/11 12:09:56" ], [ "32", "GSM1026521_AA-037_NS_NEG_PRLL.CEL.gz", "32", "11/03/11 13:05:43" ], [ "33", "GSM1026522_AA-038_OFF_MILD-INT_POS_PRLL.CEL.gz", "33", "10/28/11 12:49:24" ], [ "34", "GSM1026523_AA-039_NS_NEG_PRLL.CEL.gz", "34", "11/08/11 12:23:30" ], [ "35", "GSM1026524_AA-040_NS_NEG_PRLL.CEL.gz", "35", "11/08/11 14:03:48" ], [ "36", "GSM1026525_AA-041_OFF_MOD-PER_POS_PRLL.CEL.gz", "36", "11/08/11 13:52:39" ], [ "37", "GSM1026526_AA-042_ON_MOD-PER_POS_PRLL.CEL.gz", "37", "11/08/11 13:19:15" ], [ "38", "GSM1026527_AA-043_NS_NEG_PRLL.CEL.gz", "38", "11/18/11 14:41:29" ], [ "39", "GSM1026528_AA-044_OFF_MILD-PER_POS_PLLL.CEL.gz", "39", "11/18/11 15:14:53" ], [ "40", "GSM1026529_AA-045_NS_NEG_PRLL.CEL.gz", "40", "12/08/11 13:27:12" ], [ "41", "GSM1026530_AA-046_NS_NEG_PRLL.CEL.gz", "41", "12/08/11 12:19:51" ], [ "42", "GSM1026531_AA-047_NS_NEG_PRLL.CEL.gz", "42", "11/23/11 12:44:23" ], [ "43", "GSM1026532_AA-048_NS_NEG_PRLL.CEL.gz", "43", "11/23/11 13:39:42" ], [ "44", "GSM1026533_AA-049_OFF_MILD-INT_POS_PLLL.CEL.gz", "44", "12/23/11 13:01:50" ], [ "45", "GSM1026534_AA-051_NS_NEG_PRLL.CEL.gz", "45", "11/23/11 13:17:39" ], [ "46", "GSM1026535_AA-052_ON_MILD-PER_POS_PRLL.CEL.gz", "46", "12/16/11 13:50:43" ], [ "47", "GSM1026536_AA-053_NS_NEG_PRLL.CEL.gz", "47", "01/12/12 13:11:39" ], [ "48", "GSM1026537_AA-054_NS_NEG_PLLL.CEL.gz", "48", "12/08/11 11:57:27" ], [ "49", "GSM1026538_AA-055_OFF_MOD-PER_POS_PRLL.CEL.gz", "49", "12/08/11 13:16:02" ], [ "50", "GSM1026539_AA-056_ON_SEVERE-PER_POS_PRLL.CEL.gz", "50", "12/08/11 14:00:41" ], [ "51", "GSM1026540_AA-057_NS_NEG_PRLL.CEL.gz", "51", "12/16/11 12:55:04" ], [ "52", "GSM1026541_AA-058_OFF_SEVERE-PER_POS_PLLL.CEL.gz", "52", "12/16/11 12:21:38" ], [ "53", "GSM1026542_AA-059_NS_NEG_PRLL.CEL.gz", "53", "12/16/11 13:39:36" ], [ "54", "GSM1026543_AA-062_NS_NEG_PLLL.CEL.gz", "54", "01/12/12 14:18:21" ], [ "55", "GSM1026544_AA-063_NS_NEG_PRLL.CEL.gz", "55", "01/12/12 13:44:52" ], [ "56", "GSM1026545_AA-064_NS_NEG_PRLL.CEL.gz", "56", "12/16/11 12:43:54" ], [ "57", "GSM1026546_AA-065_OFF_MILD-INT_POS_PRLL.CEL.gz", "57", "12/23/11 12:17:22" ], [ "58", "GSM1026547_AA-066_OFF_MILD-INT_POS_PRLL.CEL.gz", "58", "01/26/12 12:39:01" ], [ "59", "GSM1026548_AA-067_OFF_MOD-PER_POS_PRLL.CEL.gz", "59", "01/26/12 13:46:32" ], [ "60", "GSM1026549_AA-068_NS_NEG_PLLL.CEL.gz", "60", "01/26/12 12:27:51" ], [ "61", "GSM1026550_AA-069_NS_NEG_PRLL.CEL.gz", "61", "02/07/12 13:04:04" ], [ "62", "GSM1026551_AA-070_OFF_MILD-PER_POS_PRLL.CEL.gz", "62", "04/06/12 13:59:05" ], [ "63", "GSM1026552_AA-073_NS_NEG_PRLL.CEL.gz", "63", "02/07/12 11:57:12" ], [ "64", "GSM1026553_AA-074_OFF_MILD-PER_POS_PLLL.CEL.gz", "64", "04/13/12 11:29:22" ], [ "65", "GSM1026554_AA-076_OFF_MOD-PER_POS_PRLL.CEL.gz", "65", "03/22/12 11:35:33" ], [ "66", "GSM1026555_AA-077_OFF_MOD-PER_POS_PRLL.CEL.gz", "66", "04/06/12 13:36:46" ], [ "67", "GSM1026556_AA-079_ON_MILD-PER_POS_PLLL.CEL.gz", "67", "04/06/12 13:25:36" ], [ "68", "GSM1026557_AA-080_OFF_MILD-PER_POS_PLLL.CEL.gz", "68", "04/06/12 13:47:53" ], [ "69", "GSM1026558_AA-082_OFF_MILD-PER_POS_PRLL.CEL.gz", "69", "04/19/12 12:15:27" ], [ "70", "GSM1026559_AA-085_ON_MOD-PER_POS_PLLL.CEL.gz", "70", "06/05/12 11:26:10" ], [ "71", "GSM1026560_AA-086_OFF_MOD-PER_POS_PLLL.CEL.gz", "71", "06/05/12 12:36:12" ], [ "72", "GSM1026561_AA-087_OFF_MOD-PER_POS_PLLL.CEL.gz", "72", "06/26/12 12:23:34" ], [ "73", "GSM1026562_AA-088_OFF_MOD-PER_POS_PLLL.CEL.gz", "73", "06/26/12 12:12:24" ], [ "74", "GSM1026563_AA-090_ON_MOD-PER_POS_PRLL.CEL.gz", "74", "07/04/12 12:07:41" ], [ "75", "GSM1026564_AA-091_ON_MOD-PER_POS_PRLL.CEL.gz", "75", "07/04/12 11:56:26" ], [ "76", "GSM1026565_AA-092_OFF_MILD-PER_POS_PLLL.CEL.gz", "76", "07/18/12 11:59:00" ], [ "77", "GSM1026566_AA-093_ON_MOD-PER_POS_PRLL.CEL.gz", "77", "07/18/12 11:47:47" ], [ "78", "GSM1026567_AA-094_ON_MOD-PER_POS_PLLL.CEL.gz", "78", "07/18/12 12:10:08" ], [ "79", "GSM1026568_AA-095_ON_MOD-PER_POS_PRLL.CEL.gz", "79", "07/18/12 12:21:06" ], [ "80", "GSM1026569_AA-096_OFF_MILD-PER_POS_PRLL.CEL.gz", "80", "08/14/12 12:18:55" ], [ "81", "GSM1026570_AA-097_ON_MOD-PER_POS_PRLL.CEL.gz", "81", "08/14/12 12:41:21" ] ];
var svgObjectNames   = [ "pca", "dens" ];

var cssText = ["stroke-width:1; stroke-opacity:0.4",
               "stroke-width:3; stroke-opacity:1" ];

// Global variables - these are set up below by 'reportinit'
var tables;             // array of all the associated ('tooltips') tables on the page
var checkboxes;         // the checkboxes
var ssrules;


function reportinit() 
{
 
    var a, i, status;

    /*--------find checkboxes and set them to start values------*/
    checkboxes = document.getElementsByName("ReportObjectCheckBoxes");
    if(checkboxes.length != highlightInitial.length)
	throw new Error("checkboxes.length=" + checkboxes.length + "  !=  "
                        + " highlightInitial.length="+ highlightInitial.length);
    
    /*--------find associated tables and cache their locations------*/
    tables = new Array(svgObjectNames.length);
    for(i=0; i<tables.length; i++) 
    {
        tables[i] = safeGetElementById("Tab:"+svgObjectNames[i]);
    }

    /*------- style sheet rules ---------*/
    var ss = document.styleSheets[0];
    ssrules = ss.cssRules ? ss.cssRules : ss.rules; 

    /*------- checkboxes[a] is (expected to be) of class HTMLInputElement ---*/
    for(a=0; a<checkboxes.length; a++)
    {
	checkboxes[a].checked = highlightInitial[a];
        status = checkboxes[a].checked; 
        setReportObj(a+1, status, false);
    }

}


function safeGetElementById(id)
{
    res = document.getElementById(id);
    if(res == null)
        throw new Error("Id '"+ id + "' not found.");
    return(res)
}

/*------------------------------------------------------------
   Highlighting of Report Objects 
 ---------------------------------------------------------------*/
function setReportObj(reportObjId, status, doTable)
{
    var i, j, plotObjIds, selector;

    if(doTable) {
	for(i=0; i<svgObjectNames.length; i++) {
	    showTipTable(i, reportObjId);
	} 
    }

    /* This works in Chrome 10, ssrules will be null; we use getElementsByClassName and loop over them */
    if(ssrules == null) {
	elements = document.getElementsByClassName("aqm" + reportObjId); 
	for(i=0; i<elements.length; i++) {
	    elements[i].style.cssText = cssText[0+status];
	}
    } else {
    /* This works in Firefox 4 */
    for(i=0; i<ssrules.length; i++) {
        if (ssrules[i].selectorText == (".aqm" + reportObjId)) {
		ssrules[i].style.cssText = cssText[0+status];
		break;
	    }
	}
    }

}

/*------------------------------------------------------------
   Display of the Metadata Table
  ------------------------------------------------------------*/
function showTipTable(tableIndex, reportObjId)
{
    var rows = tables[tableIndex].rows;
    var a = reportObjId - 1;

    if(rows.length != arrayMetadata[a].length)
	throw new Error("rows.length=" + rows.length+"  !=  arrayMetadata[array].length=" + arrayMetadata[a].length);

    for(i=0; i<rows.length; i++) 
 	rows[i].cells[1].innerHTML = arrayMetadata[a][i];
}

function hideTipTable(tableIndex)
{
    var rows = tables[tableIndex].rows;

    for(i=0; i<rows.length; i++) 
 	rows[i].cells[1].innerHTML = "";
}


/*------------------------------------------------------------
  From module 'name' (e.g. 'density'), find numeric index in the 
  'svgObjectNames' array.
  ------------------------------------------------------------*/
function getIndexFromName(name) 
{
    var i;
    for(i=0; i<svgObjectNames.length; i++)
        if(svgObjectNames[i] == name)
	    return i;

    throw new Error("Did not find '" + name + "'.");
}


/*------------------------------------------------------------
  SVG plot object callbacks
  ------------------------------------------------------------*/
function plotObjRespond(what, reportObjId, name)
{

    var a, i, status;

    switch(what) {
    case "show":
	i = getIndexFromName(name);
	showTipTable(i, reportObjId);
	break;
    case "hide":
	i = getIndexFromName(name);
	hideTipTable(i);
	break;
    case "click":
        a = reportObjId - 1;
	status = !checkboxes[a].checked;
	checkboxes[a].checked = status;
	setReportObj(reportObjId, status, true);
	break;
    default:
	throw new Error("Invalid 'what': "+what)
    }
}

/*------------------------------------------------------------
  checkboxes 'onchange' event
------------------------------------------------------------*/
function checkboxEvent(reportObjId)
{
    var a = reportObjId - 1;
    var status = checkboxes[a].checked;
    setReportObj(reportObjId, status, true);
}


/*------------------------------------------------------------
  toggle visibility
------------------------------------------------------------*/
function toggle(id){
  var head = safeGetElementById(id + "-h");
  var body = safeGetElementById(id + "-b");
  var hdtxt = head.innerHTML;
  var dsp;
  switch(body.style.display){
    case 'none':
      dsp = 'block';
      hdtxt = '-' + hdtxt.substr(1);
      break;
    case 'block':
      dsp = 'none';
      hdtxt = '+' + hdtxt.substr(1);
      break;
  }  
  body.style.display = dsp;
  head.innerHTML = hdtxt;
}
