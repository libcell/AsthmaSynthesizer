// (C) Wolfgang Huber 2010-2011

// Script parameters - these are set up by R in the function 'writeReport' when copying the 
//   template for this script from arrayQualityMetrics/inst/scripts into the report.

var highlightInitial = [ false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false ];
var arrayMetadata    = [ [ "1", "GSM98141.CEL.gz", "1", "07/28/04 15:25:27" ], [ "2", "GSM98144.CEL.gz", "2", "07/28/04 12:43:33" ], [ "3", "GSM98145.CEL.gz", "3", "09/15/04 13:01:35" ], [ "4", "GSM98148.CEL.gz", "4", "07/14/04 13:43:09" ], [ "5", "GSM98149.CEL.gz", "5", "08/03/04 13:37:19" ], [ "6", "GSM98152.CEL.gz", "6", "10/05/04 14:11:13" ], [ "7", "GSM98153.CEL.gz", "7", "07/14/04 13:55:50" ], [ "8", "GSM98155.CEL.gz", "8", "07/14/04 15:16:34" ], [ "9", "GSM98158.CEL.gz", "9", "07/28/04 16:24:15" ], [ "10", "GSM98159.CEL.gz", "10", "07/30/04 12:30:41" ], [ "11", "GSM98161.CEL.gz", "11", "08/11/04 12:19:32" ], [ "12", "GSM98163.CEL.gz", "12", "07/30/04 12:44:36" ], [ "13", "GSM98166.CEL.gz", "13", "08/11/04 12:58:44" ], [ "14", "GSM98167.CEL.gz", "14", "09/14/04 12:42:50" ], [ "15", "GSM98169.CEL.gz", "15", "09/28/04 17:16:24" ], [ "16", "GSM98171.CEL.gz", "16", "08/03/04 14:03:22" ], [ "17", "GSM98174.CEL.gz", "17", "09/15/04 13:48:44" ], [ "18", "GSM98175.CEL.gz", "18", "10/05/04 12:27:46" ], [ "19", "GSM98177.CEL.gz", "19", "08/11/04 14:00:26" ], [ "20", "GSM98180.CEL.gz", "20", "09/14/04 15:09:13" ], [ "21", "GSM98182.CEL.gz", "21", "09/14/04 15:38:11" ], [ "22", "GSM98184.CEL.gz", "22", "07/14/04 16:09:58" ], [ "23", "GSM98186.CEL.gz", "23", "07/30/04 13:55:14" ], [ "24", "GSM98187.CEL.gz", "24", "07/15/04 13:03:11" ], [ "25", "GSM98190.CEL.gz", "25", "07/15/04 13:28:27" ], [ "26", "GSM98192.CEL.gz", "26", "07/28/04 16:53:15" ], [ "27", "GSM98193.CEL.gz", "27", "10/05/04 16:08:30" ], [ "28", "GSM98195.CEL.gz", "28", "09/28/04 17:49:52" ], [ "29", "GSM98197.CEL.gz", "29", "10/05/04 17:19:51" ], [ "30", "GSM98200.CEL.gz", "30", "12/15/04 15:11:58" ], [ "31", "GSM98201.CEL.gz", "31", "12/15/04 12:55:35" ], [ "32", "GSM98204.CEL.gz", "32", "12/15/04 13:43:34" ], [ "33", "GSM98206.CEL.gz", "33", "07/15/04 16:21:43" ], [ "34", "GSM98207.CEL.gz", "34", "07/28/04 14:54:49" ], [ "35", "GSM98208.CEL.gz", "35", "06/24/04 15:35:15" ], [ "36", "GSM98209.CEL.gz", "36", "06/24/04 15:47:56" ], [ "37", "GSM98210.CEL.gz", "37", "10/05/04 13:07:26" ], [ "38", "GSM98211.CEL.gz", "38", "07/14/04 18:31:00" ], [ "39", "GSM98212.CEL.gz", "39", "07/14/04 18:45:04" ], [ "40", "GSM98213.CEL.gz", "40", "07/15/04 16:34:15" ], [ "41", "GSM98214.CEL.gz", "41", "07/28/04 17:09:07" ], [ "42", "GSM98215.CEL.gz", "42", "08/03/04 12:14:46" ], [ "43", "GSM98216.CEL.gz", "43", "08/03/04 12:27:47" ], [ "44", "GSM98217.CEL.gz", "44", "08/03/04 12:40:49" ], [ "45", "GSM98218.CEL.gz", "45", "08/03/04 16:40:06" ], [ "46", "GSM98219.CEL.gz", "46", "08/03/04 16:57:29" ], [ "47", "GSM98220.CEL.gz", "47", "08/03/04 17:12:30" ], [ "48", "GSM98221.CEL.gz", "48", "08/11/04 16:23:41" ], [ "49", "GSM98222.CEL.gz", "49", "09/14/04 17:04:23" ], [ "50", "GSM98223.CEL.gz", "50", "09/14/04 17:22:34" ], [ "51", "GSM98224.CEL.gz", "51", "12/15/04 15:25:34" ], [ "52", "GSM98225.CEL.gz", "52", "09/15/04 16:59:18" ], [ "53", "GSM98226.CEL.gz", "53", "06/24/04 14:14:04" ], [ "54", "GSM98227.CEL.gz", "54", "07/28/04 12:56:50" ], [ "55", "GSM98228.CEL.gz", "55", "09/14/04 13:11:11" ], [ "56", "GSM98229.CEL.gz", "56", "06/24/04 14:40:30" ], [ "57", "GSM98230.CEL.gz", "57", "06/24/04 14:54:05" ], [ "58", "GSM98234.CEL.gz", "58", "10/05/04 15:42:16" ], [ "59", "GSM98235.CEL.gz", "59", "10/05/04 15:55:22" ], [ "60", "GSM98236.CEL.gz", "60", "10/05/04 17:59:16" ], [ "61", "GSM98239.CEL.gz", "61", "07/30/04 14:21:31" ], [ "62", "GSM98240.CEL.gz", "62", "07/30/04 14:34:28" ], [ "63", "GSM98241.CEL.gz", "63", "08/03/04 11:59:40" ], [ "64", "GSM98242.CEL.gz", "64", "08/03/04 15:18:44" ], [ "65", "GSM98243.CEL.gz", "65", "08/03/04 15:36:13" ], [ "66", "GSM98244.CEL.gz", "66", "08/03/04 15:05:33" ], [ "67", "GSM98245.CEL.gz", "67", "08/11/04 14:29:17" ], [ "68", "GSM98251.CEL.gz", "68", "09/14/04 16:38:32" ], [ "69", "GSM98254.CEL.gz", "69", "09/15/04 15:25:38" ], [ "70", "GSM98258.CEL.gz", "70", "12/15/04 16:18:30" ] ];
var svgObjectNames   = [ "pca", "dens" ];

var cssText = ["stroke-width:1; stroke-opacity:0.4",
               "stroke-width:3; stroke-opacity:1" ];

// Global variables - these are set up below by 'reportinit'
var tables;             // array of all the associated ('tooltips') tables on the page
var checkboxes;         // the checkboxes
var ssrules;


function reportinit() 
{
 
    var a, i, status;

    /*--------find checkboxes and set them to start values------*/
    checkboxes = document.getElementsByName("ReportObjectCheckBoxes");
    if(checkboxes.length != highlightInitial.length)
	throw new Error("checkboxes.length=" + checkboxes.length + "  !=  "
                        + " highlightInitial.length="+ highlightInitial.length);
    
    /*--------find associated tables and cache their locations------*/
    tables = new Array(svgObjectNames.length);
    for(i=0; i<tables.length; i++) 
    {
        tables[i] = safeGetElementById("Tab:"+svgObjectNames[i]);
    }

    /*------- style sheet rules ---------*/
    var ss = document.styleSheets[0];
    ssrules = ss.cssRules ? ss.cssRules : ss.rules; 

    /*------- checkboxes[a] is (expected to be) of class HTMLInputElement ---*/
    for(a=0; a<checkboxes.length; a++)
    {
	checkboxes[a].checked = highlightInitial[a];
        status = checkboxes[a].checked; 
        setReportObj(a+1, status, false);
    }

}


function safeGetElementById(id)
{
    res = document.getElementById(id);
    if(res == null)
        throw new Error("Id '"+ id + "' not found.");
    return(res)
}

/*------------------------------------------------------------
   Highlighting of Report Objects 
 ---------------------------------------------------------------*/
function setReportObj(reportObjId, status, doTable)
{
    var i, j, plotObjIds, selector;

    if(doTable) {
	for(i=0; i<svgObjectNames.length; i++) {
	    showTipTable(i, reportObjId);
	} 
    }

    /* This works in Chrome 10, ssrules will be null; we use getElementsByClassName and loop over them */
    if(ssrules == null) {
	elements = document.getElementsByClassName("aqm" + reportObjId); 
	for(i=0; i<elements.length; i++) {
	    elements[i].style.cssText = cssText[0+status];
	}
    } else {
    /* This works in Firefox 4 */
    for(i=0; i<ssrules.length; i++) {
        if (ssrules[i].selectorText == (".aqm" + reportObjId)) {
		ssrules[i].style.cssText = cssText[0+status];
		break;
	    }
	}
    }

}

/*------------------------------------------------------------
   Display of the Metadata Table
  ------------------------------------------------------------*/
function showTipTable(tableIndex, reportObjId)
{
    var rows = tables[tableIndex].rows;
    var a = reportObjId - 1;

    if(rows.length != arrayMetadata[a].length)
	throw new Error("rows.length=" + rows.length+"  !=  arrayMetadata[array].length=" + arrayMetadata[a].length);

    for(i=0; i<rows.length; i++) 
 	rows[i].cells[1].innerHTML = arrayMetadata[a][i];
}

function hideTipTable(tableIndex)
{
    var rows = tables[tableIndex].rows;

    for(i=0; i<rows.length; i++) 
 	rows[i].cells[1].innerHTML = "";
}


/*------------------------------------------------------------
  From module 'name' (e.g. 'density'), find numeric index in the 
  'svgObjectNames' array.
  ------------------------------------------------------------*/
function getIndexFromName(name) 
{
    var i;
    for(i=0; i<svgObjectNames.length; i++)
        if(svgObjectNames[i] == name)
	    return i;

    throw new Error("Did not find '" + name + "'.");
}


/*------------------------------------------------------------
  SVG plot object callbacks
  ------------------------------------------------------------*/
function plotObjRespond(what, reportObjId, name)
{

    var a, i, status;

    switch(what) {
    case "show":
	i = getIndexFromName(name);
	showTipTable(i, reportObjId);
	break;
    case "hide":
	i = getIndexFromName(name);
	hideTipTable(i);
	break;
    case "click":
        a = reportObjId - 1;
	status = !checkboxes[a].checked;
	checkboxes[a].checked = status;
	setReportObj(reportObjId, status, true);
	break;
    default:
	throw new Error("Invalid 'what': "+what)
    }
}

/*------------------------------------------------------------
  checkboxes 'onchange' event
------------------------------------------------------------*/
function checkboxEvent(reportObjId)
{
    var a = reportObjId - 1;
    var status = checkboxes[a].checked;
    setReportObj(reportObjId, status, true);
}


/*------------------------------------------------------------
  toggle visibility
------------------------------------------------------------*/
function toggle(id){
  var head = safeGetElementById(id + "-h");
  var body = safeGetElementById(id + "-b");
  var hdtxt = head.innerHTML;
  var dsp;
  switch(body.style.display){
    case 'none':
      dsp = 'block';
      hdtxt = '-' + hdtxt.substr(1);
      break;
    case 'block':
      dsp = 'none';
      hdtxt = '+' + hdtxt.substr(1);
      break;
  }  
  body.style.display = dsp;
  head.innerHTML = hdtxt;
}
